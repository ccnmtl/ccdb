from distutils.core import setup
setup(name='django-jsonfield',
      version='0.5',
      packages=['jsonfield'])
